/* 
 * File:   main.cpp
 * Author: Kurt Montoya
 *
 * Created on March 8, 2015, 4:33 PM
 *  purpose: answer the question
 */

#include <iostream>
using namespace std;

//user libraries

//global constants

//function prototypes

//execution begins

int main(int argc, char** argv) {
    //declare variables
    float Stax,Ctax,prchs,total;
    Stax=0.04;//state tax
    Ctax=0.02;//county tax
    prchs=95;//purchase
    total=prchs*(Stax+Ctax);//total tax amount
    cout<<"Total tax amount: "<<"$"<<total<<endl;
    
    return 0;
}

