/* 
 * File:   main.cpp
 * Author: Kurt Montoya
 *
 * Created on March 4, 2015, 9:45 AM
 *      Purpose: solve the problem
 */

#include <iostream>
using namespace std;

//user libraries

//global constants

//function prototypes

//execution begins

int main(int argc, char** argv) {
    //declare variables
    unsigned short Var1,Var2,total;
    //input values
    Var1=50;//variable 1
    Var2=100;//variable 2
    //calculation
    total=Var1+Var2;
    cout<<"Total value:"<<total<<endl;
    return 0;
}

