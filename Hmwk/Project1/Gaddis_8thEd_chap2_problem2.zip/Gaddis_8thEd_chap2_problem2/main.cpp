/* 
 * File:   main.cpp
 * Author: Kurt Montoya
 *
 * Created on March 4, 2015, 7:52 AM
 *      Purpose: 2nd Homework Problem
 */

#include <iostream>
using namespace std;

//user libraries

//global constants

//function prototypes

//execution begins

int main(int argc, char** argv) {
    //declare variables
    unsigned int NSales,total;
    float pSales;
    //assigned values
    NSales=8.6e6;//total sales
    pSales=0.58;//percent of total sales
    //calculate
    total=NSales*pSales;
    cout<<"Total sales for company:"<<total<<endl;
    
    return 0;
}

